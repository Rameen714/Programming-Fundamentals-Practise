#include <iostream>
using namespace std;
int main()
{
    int n,a=0,b,c;
    cout<<"enter the number up to which u want to print ticktock series";
    cin>>n;
    b=2;
    c=5;
    if(n%2!=0) a=1;
    a=a+(n/2);
    for(int i=1;i<=a;i++)
    {
        
        cout<<b<<"-";
        cout<<c<<"+";
        b=b+2;
        c=c+5;
    }
  
    



    return 0;
}