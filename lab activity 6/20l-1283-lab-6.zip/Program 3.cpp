
#include <iostream>

using namespace std;

int main()
{
    int n=0,j=0;
    cin>>n;
    //program to print upper half hollow pattern
    for(int i=1;i<=n;i++)
    {
        for(int space=i;space<n;space++ )
        {
            cout<<" ";
        }
        
        while(j!=(2*i-1))
        {
            if(j==0 || j==2*i-2)
                cout<<"*";
            else
                cout<<" ";
            j++;
            ;
        }
        j=0;
        cout<<endl;
    }
    for(int i=n-1;i>0;i--)
    {
        for(int space=i;space<n;space++ )
        {
            cout<<" ";
        }
        
        while(j!=(2*i-1))
        {
            if(j==0 || j==2*i-2)
                cout<<"*";
            else
                cout<<" ";
            j++;
        }
        j=0;
        cout<<endl;
    }
    cout<<endl;
    //program to print X pattern
    for (int a=1;a<=n;a++)
    {
        for (int b=1;b<=n;b++)
        {
            if(b==a || b==(n+1-a))
                cout<<"*";
            else
                cout<<" ";
        }
      cout<<endl;  
    }
    return 0;
}
