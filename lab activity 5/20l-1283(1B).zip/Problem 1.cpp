#include <iostream>

using namespace std;

void cin_array(int arr[],int n)
{
    for(int i=0;i<n;i++)
        cin>>arr[i];
    return;
}
void cout_Array( int arr[], int n)
{
    for(int j=0;j<n;j++)
        cout<<arr[j]<<" ";
    cout<<endl;
    return;
}
int main()
{
    int n,c=0;
    cout<<"enter number of elements to be entered in array"<<endl;
    cin>>n;
    int arr_1[50];
    cin_array( arr_1, n);
    cout_Array( arr_1, n);
    int arr_2[100];
    cin_array( arr_2, n);
    cout_Array( arr_2, n);
    int arr_3[150];        
    cin_array( arr_3, n);
    cout_Array( arr_3, n);
    
    return 0;
}
